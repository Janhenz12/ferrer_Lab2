import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: myApp(),
  ));
}

class myApp extends StatelessWidget{

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text(
            '''My Laboratory 2
     Luffy Gears'''
        ),
        centerTitle: true,
      ),
      body: Container(
        color: Colors.lightGreenAccent,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget> [
            Expanded(
              flex: 2,
             child: Column(
                //
                children: [
                  Image.asset('image/1.gif'),
                  Container(
                    padding: EdgeInsets.all(10.0),
                      child: Text('Gear 2')
                  ),
              Icon(
                Icons.star_rate,
                color: Colors.red,
                size: 15,
              ),
                ],
              ),
            ),

            Expanded(
              flex: 2,
              child: Column(
                children: [
                  Image.asset('image/4.gif'),
                  Container(
                    padding: EdgeInsets.all(10.0),
                    color: Colors.lightGreenAccent[200],
                    child: Text ('Gear 4')
                  ),
                    Icon(
                      Icons.star_rate,
                      color: Colors.blue,
                      size: 15,
                    ),
            ],
              ),),
            Expanded(
              flex: 2,
              child: Column(
                children: [
                  Image.asset('image/5.gif'),
                  Container(
                    padding: EdgeInsets.all(10.0),
                      child: Text ('Gear 5')
                  ),
                Icon(
                    Icons.star_rate,
                    color: Colors.black,
                    size: 15,
                ),
                ],
              ),
            ),
        ],
      ),
      ),
    );
  }
}