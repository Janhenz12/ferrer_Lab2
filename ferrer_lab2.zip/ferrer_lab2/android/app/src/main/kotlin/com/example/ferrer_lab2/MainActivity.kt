package com.example.ferrer_lab2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
